<?php
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;

  require 'PHPMailer/src/Exception.php';
  require 'PHPMailer/src/PHPMailer.php';

  $mail = new PHPMailer(true);
  $mail -> CharSet = 'UTF-8';
  $mail -> setLanguage('ru', 'phpmailer/language/');
  $mail -> IsHTML(true);

  //От кого письмо
  $mail -> setForm('info@fls.guru', 'Фрилансер по жизни');
  // Кому отправить
  $mail -> addAddress('konstantin.pak.it@gmail.com');
  // Тема письма
  $mail -> Subject = "Привет! Это 'Фрилансер по жизни'";


  // Тело письма
  $body = '<h1>Встречайте супер-письмо</h1>';

  if(trim(!empty($_POST['first-name']))) {
    $body.='<p><strong>Имя</strong> ' .$_POST['first-name'].'</p>';
  }

  if(trim(!empty($_POST['tel']))) {
    $body.='<p><strong>Tel:</strong> ' .$_POST['tel'].'</p>';
  }

  if(trim(!empty($_POST['email']))) {
    $body.='<p><strong>Email:</strong> ' .$_POST['email'].'</p>';
  }

  if(trim(!empty($_POST['city']))) {
    $body.='<p><strong>Город:</strong> ' .$_POST['city'].'</p>';
  }

  if(trim(!empty($_POST['desc']))) {
    $body.='<p><strong>Описание груза:</strong> ' .$_POST['desc'].'</p>';
  }


  //Отправляем
  if (!$mail -> send()) {
    $message = 'Ошибка';
  } else {
    $message = 'Данные отправлены!';
  }

  $response = ['message' => $message];
  echo json_encode($response);



?>